<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="jumbotron-gradient" style="background: #f2ae72">
            <div class="container container-alt">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="panel panel-default panel-heading-overview">
                            Recipes
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="panel panel-default">
                                <div class="panel-image"
                                     style="background-image: url('/uploads/<?php echo e($recipe->image); ?>')">
                                    <div class="text-center">
                                        <h1 style="font-size: 3em" class="text-block"><?php echo e($recipe->name); ?></h1> <br>
                                        <br>
                                        <h1 style="font-size: 2em" class="text-block"><?php echo e($recipe->category); ?></h1>
                                    </div>
                                </div>
                                <div style="padding: 1em">
                                    <input id="likes" name="" type="text" class="rating rating-loading" data-size="sm"
                                           value="<?php echo e($recipe->Ratings->avg('rating')); ?>" disabled>
                                    <button class="btn btn-default">
                                        <a href="/recipepage/<?php echo e($recipe->id); ?>">Read more</a>
                                    </button>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                    <div class="container container-alt">
                        <div class="row">
                            <div class=" col-xs-12 col-sm-12 col-md-4 col-lg-4"></div>
                            <div class=" col-xs-12 col-sm-12 col-md-4 col-lg-4" style="alignment: center">
                                <?php echo e($recipes->links()); ?>

                            </div>
                            <div class=" col-xs-12 col-sm-12 col-md-4 col-lg-4"></div>
                        </div>
                    </div>

                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>