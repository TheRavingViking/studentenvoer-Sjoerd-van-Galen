<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="jumbotron" style="background:#33658A;">
            <div class="container container-alt">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="panel panel-default panel-heading-overview">
                            Breakfast
                            <div>
                                <button class="btn btn-default">
                                    <a href="/breakfast">More recipes</a>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $breakfasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breakfast): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="panel panel-default">
                                <div class="panel-image"
                                     style="background-image: url('/uploads/<?php echo e($breakfast->image); ?>')">
                                    <div class="text-center">
                                        <h1 style="font-size: 3em" class="text-block"><?php echo e($breakfast->name); ?></h1> <br>
                                        <br>
                                        <h1 style="font-size: 2em" class="text-block"><?php echo e($breakfast->category); ?></h1>
                                    </div>
                                </div>
                                <div style="padding: 1em">
                                    <input id="likes" name="" type="text" class="rating rating-loading" data-size="sm"
                                           value="<?php echo e(round($breakfast->Ratings->avg('rating'))); ?>" disabled>
                                    <button class="btn btn-default">
                                        <a href="/recipepage/<?php echo e($breakfast->id); ?>">Read more</a>
                                    </button>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </div>
            </div>
        </div>

        <div class="jumbotron" style="background:#86BBD8;">
            <div class="container container-alt">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="panel panel-default panel-heading-overview">
                            Lunch
                            <div>
                                <button class="btn btn-default">
                                    <a href="/lunch">More recipes</a>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $lunches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lunch): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="panel panel-default">
                                <div class="panel-image" style="background-image: url('/uploads/<?php echo e($lunch->image); ?>')">
                                    <div class="text-center">
                                        <h1 style="font-size: 3em" class="text-block"><?php echo e($lunch->name); ?></h1> <br> <br>
                                        <h1 style="font-size: 2em" class="text-block"><?php echo e($lunch->category); ?></h1>
                                    </div>
                                </div>
                                <div style="padding: 1em">
                                    <input id="likes" name="" type="text" class="rating rating-loading" data-size="sm"
                                           value="<?php echo e(round($lunch->Ratings->avg('rating'))); ?>" disabled>
                                    <button class="btn btn-default">
                                        <a href="/recipepage/<?php echo e($lunch->id); ?>">Read more</a>
                                    </button>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
        </div>


        <div class="jumbotron" style="background: #2F4858;">
            <div class="container container-alt">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="panel panel-default panel-heading-overview">
                            Dinner
                            <div>
                                <button class="btn btn-default">
                                    <a href="/dinner">More recipes</a>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $dinners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dinner): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="panel panel-default">
                                <div class="panel-image" style="background-image: url('/uploads/<?php echo e($dinner->image); ?>')">
                                    <div class="text-center">
                                        <h1 style="font-size: 3em" class="text-block"><?php echo e($dinner->name); ?></h1> <br> <br>
                                        <h1 style="font-size: 2em" class="text-block"><?php echo e($dinner->category); ?></h1>
                                    </div>
                                </div>
                                <div style="padding: 1em">
                                    <input id="likes" name="" type="text" class="rating rating-loading" data-size="sm"
                                           value="<?php echo e(round($dinner->Ratings->avg('rating'))); ?>" disabled>
                                    <button class="btn btn-default">
                                        <a href="/recipepage/<?php echo e($dinner->id); ?>">Read more</a>
                                    </button>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
        </div>

        <div class="jumbotron" style="background:#2D3142;">
            <div class="container container-alt">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="panel panel-default panel-heading-overview">
                            Desserts
                            <div>
                                <button class="btn btn-default">
                                    <a href="/dessert">More recipes</a>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $desserts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dessert): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="panel panel-default">
                                <div class="panel-image"
                                     style="background-image: url('/uploads/<?php echo e($dessert->image); ?>')">
                                    <div class="text-center">
                                        <h1 style="font-size: 3em" class="text-block"><?php echo e($dessert->name); ?></h1> <br> <br>
                                        <h1 style="font-size: 2em" class="text-block"><?php echo e($dessert->category); ?></h1>
                                    </div>
                                </div>
                                <div style="padding: 1em">
                                    <input id="likes" name="" type="text" class="rating rating-loading" data-size="sm"
                                           value="<?php echo e(round($dessert->Ratings->avg('rating'))); ?>" disabled>
                                    <button class="btn btn-default">
                                        <a href="/recipepage/<?php echo e($dessert->id); ?>">Read more</a>
                                    </button>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>