<?php ($i = 1); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="jumbotron jumbotron-image" style="background-image: url('/uploads/<?php echo e($recipes->image); ?>')">
            <div class="text-center">
                <h1 class="text-block"><?php echo e($recipes->name); ?></h1> <br> <br>
                <p class="text-block"><?php echo e($recipes->category); ?></p>
            </div>
        </div>
        <div class="jumbotron" style="background: #2F4858">
            <div class="container container-alt">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
                        <input id="likes" name="likes" type="text" class="" data-size="lg"
                               value="<?php echo e(round($recipes->Ratings->avg('rating'))); ?>">
                    </div>
                    <?php if(Auth::check()): ?>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <form method="post" action="/deleteRecipe">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="recipe_id" value="<?php echo e($recipes->id); ?>">
                            <span class="input-group-btn">
                            <button class="btn btn-danger" type="submit">Delete recipe</button>
                        </span>
                        </form>
                    </div>
                        <?php endif; ?>
                </div>
                <?php echo e($recipes->description); ?>

            </div>
        </div>
        <div class="jumbotron" style="background: #33658A;">
            <div class="container container-alt" style="color: white">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <h2> Ingredients </h2>
                        <hr>
                        <br>
                        <?php $__currentLoopData = $recipes->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="recipe-list">
                                <i class="glyphicon glyphicon-ok"></i> <?php echo e($ingredient->name); ?> <br>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
                        <h2> Steps </h2>
                        <hr>
                        <br>

                        <?php $__currentLoopData = $recipes->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="recipe-list" style="">
                                <B> Step <?php echo e($i++); ?>: </B> <?php echo e($step->description); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php if(!empty($recipes->comments)): ?>
            <div class="jumbotron" style="background: #86BBD8">
                <div class="container container-alt">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="color: white">
                            <?php $__currentLoopData = $recipes->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                Posted by <?php echo e($comment->naam); ?> <br>
                                <?php echo e($comment->comment); ?><br>
                                at <?php echo e($comment->created_at); ?><br>
                                <?php if(Auth::check()): ?>
                                <form method="post" action="/deleteComment">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                                    <span class="input-group-btn">
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </span>
                                </form>
                                <?php endif; ?>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>


        <?php else: ?>

        <?php endif; ?>
    </div>

    <div class="jumbotron" style="background: #f5f8fa; padding-bottom: 25px">
        <div class="container container-alt">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <?php if($recipes->comments == "[]"): ?>
                    <br>
                    <h2 style="color: black">No comments yet! Be the first to comment!</h2>
                    <br>
                <?php endif; ?>
                <form class="form-horizontal" method="post" action="/addcomment">

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <label class="control-label" for="name"></label>
                    <input id="name" name="name" type="text" placeholder="Name"
                           class="form-control input-md" required="">


                    <label class="control-label" for="Email"></label>
                    <input id="email" name="email" type="text" placeholder="Fill in you email"
                           class="form-control input-md" required="">


                    <label class="control-label" for="comment"></label>
                    <textarea class="form-control" id="comment"
                              name="comment" required=""
                              placeholder="Write your comment here" style="resize: vertical;"></textarea>

                    <br>
                    <div>
                        <label for="rate" class="control-label" style="color: black">Rate this
                            recipe</label>
                        <input id="rate" name="rate" class="rating rating-loading" required>
                    </div>
                    <br>

                    <label class="control-label" for="postcomment"></label>
                    <input type="hidden" name="id" value="<?php echo e($recipes->id); ?>">
                    <button id="postcomment" name="postcomment" class="btn btn-primary">Post
                    </button>


                </form>
            </div>

        </div>
    </div>

    <script>

        $('#likes').rating({displayOnly: true});


    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>